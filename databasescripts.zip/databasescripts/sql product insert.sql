/*
-- Query: SELECT * FROM springboot.product
LIMIT 0, 1000

-- Date: 2024-01-28 18:14
*/
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (107,'Pomodorini Pasta',450.00,'/foodimages/pasta.jpg','2024-01-28 16:09:49.633000','2024-01-28 16:09:49.633000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (108,'Pork Salad',500.00,'/foodimages/porksalad.jpg','2024-01-28 16:10:56.408000','2024-01-28 16:10:56.408000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (109,'Shrimp Rice',600.00,'/foodimages/shrimprice.jpg','2024-01-28 16:11:42.126000','2024-01-28 16:11:42.126000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (110,'Steamed Salmon',600.00,'/foodimages/salmon.jpg','2024-01-28 16:12:10.169000','2024-01-28 16:12:10.169000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (111,'Chicken Fillet',400.00,'/foodimages/pule.jpeg','2024-01-28 16:12:40.514000','2024-01-28 16:12:40.515000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (112,'Tuna Salad',400.00,'/foodimages/tunasalad.jpg','2024-01-28 16:13:08.150000','2024-01-28 16:13:08.150000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (113,'Caesar Salad',400.00,'/foodimages/caesarsalad.jpg','2024-01-28 16:13:42.011000','2024-01-28 16:13:42.011000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (114,'Farm Salad',250.00,'/foodimages/sallatefshati.jpg','2024-01-28 16:14:18.485000','2024-01-28 16:14:18.485000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (115,'Olive Oil Pasta',400.00,'/foodimages/pasta.jpg','2024-01-28 16:14:47.074000','2024-01-28 16:14:47.074000');
INSERT INTO `` (`id`,`name`,`unit_price`,`image_url`,`date_created`,`last_updated`) VALUES (116,'Olive Oil Pasta',400.00,'/foodimages/pasta.jpg','2024-01-28 16:19:35.547000','2024-01-28 16:19:35.547000');
